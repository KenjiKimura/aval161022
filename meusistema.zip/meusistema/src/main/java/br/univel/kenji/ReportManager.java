package br.univel.kenji;

import java.util.List;
import java.util.Locale;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;

public class ReportManager {
	
	public void exportarCustom() {
		String strFile = "C:\\Users\\ektkimura\\JaspersoftWorkspace\\MyReports\\CustomFields.jasper";
		
		AlunoDao dao = new AlunoDao();
		List<Aluno> lista = dao.getTodos();
		
		JRDataSource customDs = new AlunoReport(lista); 
		
		JasperPrint jp;
		
		try {
			jp = JasperFillManager.fillReport(strFile,null , customDs);
			
			Locale locale = Locale.getDefault();
			JasperViewer.viewReport(jp, false, locale);
		} catch (JRException e){
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		ReportManager rm = new ReportManager();
		rm.exportarCustom();
		
		
	}
}
