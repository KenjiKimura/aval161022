package br.univel.kenji;

import java.awt.EventQueue;


public class Principal extends TelaPrincipal{

	
private AlunoModel modelo;
	
	public Principal() {
		super();
		limparCampos();
		configurarBotoes();
		configuraTabela();
		configuraMenus();
	}

	private void configuraMenus() {
		// TODO Auto-generated method stub
		
	}

	private void configuraTabela() {
		// TODO Auto-generated method stub
		
	}

	private void configurarBotoes() {
		// TODO Auto-generated method stub
		
	}

	private void limparCampos() {
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal frame = new TelaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
}
