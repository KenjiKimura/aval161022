package br.univel.kenji;

public class Aluno {
	
	private Long id;
	private String nome;
	private String sobrenome;
	private String ra;
}
