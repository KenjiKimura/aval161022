package br.univel.kenji;

import javax.swing.table.AbstractTableModel;


public abstract class AlunoModel extends AbstractTableModel{

}
